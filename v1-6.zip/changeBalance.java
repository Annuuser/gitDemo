Class changeBalance{
	private changeTest = "v1.6";
}
